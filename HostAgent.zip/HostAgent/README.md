# HostAgent — ایجنت هوش مصنوعی اندروید برای مدیریت و کدنویسی روی هاست

یک برنامه اندروید (Kotlin + Jetpack Compose) که به‌صورت **ایجنت** کار می‌کند: شما دستور می‌دهید، مدل هوش مصنوعی خودش فایل‌ها را بررسی می‌کند، کد می‌نویسد، روی هاست آپلود/ویرایش می‌کند و نتیجه را تست می‌کند.

## امکانات

**پرووایدرها (چندتایی، قابل افزودن):**
- **Claude** از طریق Anthropic Messages API (با Prompt Caching برای کاهش هزینه)
- **هر پرووایدر سازگار با OpenAI** فقط با «آدرس + کلید API»: OpenAI، OpenRouter، DeepSeek، Gemini، Groq، Ollama/LM Studio محلی، گیت‌وی‌های کاستم و…
- پراکسی‌های سازگار با Anthropic (نوع Anthropic + Base URL دلخواه)
- هدرهای HTTP اضافه برای هر پرووایدر و دکمه «تست اتصال»

**اتصال به هاست‌ها:**
| روش | کاربرد |
|---|---|
| FTP / FTPS | سی‌پنل، دایرکت‌ادمین، پلسک و تقریباً همه هاست‌های اشتراکی |
| SFTP (SSH) | VPS و هاست‌هایی که SSH دارند — با رمز یا کلید خصوصی؛ اجرای دستور shell |
| cPanel UAPI | دیتابیس، دامنه، ایمیل، SSL و… با API Token |
| DirectAdmin API | دستورات `CMD_API_*` با رمز یا Login Key |

**ابزارهای ایجنت:** `remote_list`، `remote_read`، `remote_write`، `remote_edit`، `remote_mkdir`، `remote_delete`، `remote_rename`، `remote_upload_local`، `remote_download_local`، `panel_api`، `ssh_exec`، `local_*` (فضای کاری داخل برنامه)، `http_request` (تست سایت).

**امنیت:**
- کلیدهای API و رمزها با Android Keystore رمزنگاری می‌شوند (EncryptedSharedPreferences).
- عملیات تغییردهنده (نوشتن، حذف، API پنل، SSH) قبل از اجرا از شما اجازه می‌گیرند (در تنظیمات قابل خاموش‌کردن، یا «اجازه برای کل این گفتگو»).
- دکمه توقف، درخواست در حال اجرا را فوراً قطع می‌کند.

## ساخت APK

### راه ۱ — بدون نصب چیزی (GitHub Actions)
1. یک ریپازیتوری در GitHub بسازید و محتوای این پوشه را push کنید.
2. در تب **Actions** گردش‌کار «Build APK» خودکار اجرا می‌شود (یا دستی با Run workflow).
3. بعد از اتمام (حدود ۵ تا ۸ دقیقه)، در صفحه اصلی ریپازیتوری به بخش **Releases** بروید و فایل **HostAgent.apk** را مستقیم دانلود و نصب کنید.
   لینک مستقیم همیشه به آخرین نسخه: `https://github.com/USERNAME/REPO/releases/latest/download/HostAgent.apk`

### راه ۲ — Android Studio
1. پوشه پروژه را با Android Studio (نسخه Koala یا جدیدتر) باز کنید.
2. Gradle Sync را بزنید (JDK 17).
3. `Build > Build APK(s)` یا مستقیم روی گوشی Run کنید.

## راه‌اندازی در برنامه

### ۱) افزودن Claude
تب **پرووایدرها** ← `+` ← الگوی **Claude** ← کلید API از [console.anthropic.com](https://console.anthropic.com) ← مدل (مثلاً `claude-sonnet-5-5` یا `claude-opus-5-5`) ← تست اتصال ← ذخیره.

### ۲) افزودن پرووایدر کاستم
نوع **OpenAI-compatible** ← آدرس پایه تا `/v1` (مثلاً `https://my-gateway.com/v1`) ← کلید ← نام مدل.
مدل حتماً باید از **function calling / tools** پشتیبانی کند تا ایجنت بتواند کار کند.

### ۳) افزودن هاست سی‌پنل
- **فایل‌ها:** FTP (یا FTPS)، آدرس `ftp.yourdomain.com`، پورت 21، نام کاربری و رمز سی‌پنل/اکانت FTP، ریشه `/public_html`.
- **API (اختیاری):** cPanel ← آدرس `https://yourdomain.com:2083` ← نام کاربری سی‌پنل ← API Token
  (ساخت توکن: سی‌پنل ← Security ← **Manage API Tokens** ← Create).

### ۴) افزودن هاست دایرکت‌ادمین
- **فایل‌ها:** FTP، ریشه معمولاً `/domains/yourdomain.com/public_html`.
- **API (اختیاری):** DirectAdmin ← `https://yourdomain.com:2222` ← نام کاربری ← رمز یا **Login Key**
  (ساخت: دایرکت‌ادمین ← Login Keys؛ فقط دستورهای لازم را مجاز کنید).

## نمونه دستورها
- «فایل‌های هاست mysite را بررسی کن و بگو چه CMSی نصب است.»
- «یک لندینگ ریسپانسیو فارسی با فرم تماس PHP بساز و در پوشه /promo آپلود کن، بعد تستش کن.»
- «در سی‌پنل یک دیتابیس و یوزر MySQL جدید بساز و به هم وصل کن.»
- «فایل wp-config.php را بخوان و حالت دیباگ را روشن کن.»
- «از کل پوشه theme بکاپ بگیر و رنگ هدر را عوض کن.»

## ساختار کد
```
app/src/main/java/com/hostagent/app/
├── MainActivity.kt          ناوبری اصلی (ایجنت / پرووایدرها / هاست‌ها / تنظیمات)
├── data/                    مدل‌ها و ذخیره‌سازی رمزنگاری‌شده
├── llm/                     AnthropicProvider ، OpenAICompatProvider و انواع مشترک
├── remote/                  FtpFs ، SftpFs ، PanelApi (cPanel/DirectAdmin)
├── agent/                   AgentTools (تعریف و اجرای ابزارها) و AgentRunner (حلقه ایجنت)
└── ui/                      صفحه‌های Compose و ViewModel
```

**افزودن ابزار جدید:** در `AgentTools.kt` یک `def(...)` به `definitions` و یک شاخه در `run()` اضافه کنید.
**افزودن نوع پرووایدر جدید:** رابط `LlmProvider` را پیاده‌سازی و در `MainViewModel.createProvider` ثبت کنید.

## نکات
- اتصال SFTP کلید میزبان را بررسی نمی‌کند (`StrictHostKeyChecking=no`)؛ برای سرورهای حساس قابل تغییر است.
- برخی سرورهای FTPS که «TLS session reuse» اجباری دارند ممکن است با FTPS مشکل داشته باشند؛ در این حالت از FTP یا SFTP استفاده کنید.
- خواندن فایل‌های متنی تا ۲۰۰ هزار کاراکتر؛ برای فایل‌های باینری از `remote_upload_local`/`remote_download_local` استفاده می‌شود.
- تاریخچه گفتگو فعلاً فقط تا بسته‌شدن برنامه نگه داشته می‌شود.
