package com.hostagent.app.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import com.hostagent.app.llm.PrettyJson
import kotlinx.serialization.json.JsonObject

/** Code, paths and JSON are always shown left-to-right, even in the Persian (RTL) UI. */
@Composable
fun Ltr(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { content() }
}

@Composable
fun CodeText(text: String, maxLines: Int = Int.MAX_VALUE) {
    Ltr { Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, maxLines = maxLines) }
}

@Composable
fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    secret: Boolean = false,
    singleLine: Boolean = true,
    number: Boolean = false,
    ltr: Boolean = true
) {
    val field = @Composable {
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            label = { Text(label) },
            singleLine = singleLine,
            maxLines = if (singleLine) 1 else 6,
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(
                keyboardType = when {
                    number -> KeyboardType.Number
                    secret -> KeyboardType.Password
                    else -> KeyboardType.Text
                }
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
    if (ltr) Ltr(field) else field()
}

fun pretty(o: JsonObject): String = runCatching { PrettyJson.encodeToString(JsonObject.serializer(), o) }.getOrDefault(o.toString())
