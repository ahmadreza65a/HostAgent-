package com.hostagent.app.remote

import com.hostagent.app.data.HostConfig
import com.hostagent.app.data.PanelType
import com.hostagent.app.llm.Http
import okhttp3.Credentials
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request

/**
 * Raw access to control-panel APIs.
 *  - cPanel UAPI:  endpoint "Module/function"  -> https://host:2083/execute/Module/function
 *                  (also accepts "json-api/..." for API2)
 *  - DirectAdmin:  endpoint "CMD_API_SHOW_DOMAINS" etc. -> https://host:2222/CMD_API_...
 *                  (also accepts the newer "api/..." endpoints)
 */
object PanelApi {

    fun call(h: HostConfig, endpoint: String, params: Map<String, String>, method: String = "GET"): String {
        require(h.panelType != PanelType.NONE) { "Host '${h.name}' has no control panel configured." }
        val base = h.panelUrl.trim().trimEnd('/')
        require(base.isNotEmpty()) { "Panel URL is empty for host '${h.name}'." }

        val ep = endpoint.trim().trimStart('/')
        val path = when (h.panelType) {
            PanelType.CPANEL -> if (ep.startsWith("execute/") || ep.startsWith("json-api/")) ep else "execute/$ep"
            else -> ep
        }

        val p = params.toMutableMap()
        if (h.panelType == PanelType.DIRECTADMIN && path.startsWith("CMD_API") && "json" !in p) p["json"] = "yes"

        val url = "$base/$path".toHttpUrl().newBuilder()
        val rb = Request.Builder()
        if (method.equals("POST", ignoreCase = true)) {
            val form = FormBody.Builder()
            p.forEach { (k, v) -> form.add(k, v) }
            rb.url(url.build()).post(form.build())
        } else {
            p.forEach { (k, v) -> url.addQueryParameter(k, v) }
            rb.url(url.build()).get()
        }

        if (h.panelType == PanelType.CPANEL && h.panelUseToken) {
            rb.header("Authorization", "cpanel ${h.panelUser}:${h.panelSecret}")
        } else {
            rb.header("Authorization", Credentials.basic(h.panelUser, h.panelSecret))
        }

        return Http.clientFor(h.insecureTls).newCall(rb.build()).execute().use { r ->
            "HTTP ${r.code}\n" + r.body?.string().orEmpty()
        }
    }

    /** Lightweight call used by the "Test connection" button. */
    fun ping(h: HostConfig): String = when (h.panelType) {
        PanelType.CPANEL -> call(h, "Quota/get_quota_info", emptyMap())
        PanelType.DIRECTADMIN -> call(h, "CMD_API_SHOW_USER_CONFIG", emptyMap())
        PanelType.NONE -> "no panel"
    }
}
