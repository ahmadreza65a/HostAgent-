@file:OptIn(ExperimentalMaterial3Api::class)

package com.hostagent.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(vm: MainViewModel) {
    var approval by remember { mutableStateOf(vm.settings.requireApproval) }
    var steps by remember { mutableStateOf(vm.settings.maxSteps.toString()) }
    var custom by remember { mutableStateOf(vm.settings.customInstructions) }
    var saved by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("تنظیمات") })
        Column(
            Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("تأیید قبل از تغییر روی هاست")
                    Text(
                        "قبل از نوشتن، ویرایش، حذف فایل، دستور SSH یا فراخوانی API پنل از شما اجازه گرفته می‌شود.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Switch(checked = approval, onCheckedChange = { approval = it; saved = false })
            }
            Field("حداکثر گام‌های ایجنت در هر دستور", steps, { steps = it.filter(Char::isDigit); saved = false }, number = true)
            Field(
                "دستورالعمل دائمی برای ایجنت (اختیاری)", custom, { custom = it; saved = false },
                singleLine = false, ltr = false
            )
            Text(
                "فایل‌های محلی ایجنت در پوشه خصوصی برنامه نگه داشته می‌شوند:\n${vm.tools.workspace.path}",
                style = MaterialTheme.typography.bodySmall
            )
            Button(onClick = {
                vm.updateSettings(
                    vm.settings.copy(
                        requireApproval = approval,
                        maxSteps = steps.toIntOrNull()?.coerceIn(1, 500) ?: 40,
                        customInstructions = custom
                    )
                )
                saved = true
            }) { Text(if (saved) "ذخیره شد ✓" else "ذخیره") }
        }
    }
}
