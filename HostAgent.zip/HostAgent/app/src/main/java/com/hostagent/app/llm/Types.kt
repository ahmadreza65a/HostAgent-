package com.hostagent.app.llm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class ToolDef(val name: String, val description: String, val schema: JsonObject)
data class ToolCall(val id: String, val name: String, val input: JsonObject)
data class ToolResult(val toolCallId: String, val content: String, val isError: Boolean = false)

/** An attached image (screenshot/photo), already resized and base64-encoded. */
data class ImageData(val mediaType: String, val base64: String)

/** Provider-neutral conversation history. Each provider converts it to its own wire format. */
sealed class ChatMsg {
    data class User(val text: String, val images: List<ImageData> = emptyList()) : ChatMsg()
    data class Assistant(val text: String, val toolCalls: List<ToolCall>) : ChatMsg()
    data class Tools(val results: List<ToolResult>) : ChatMsg()
}

data class LlmResponse(val text: String, val toolCalls: List<ToolCall>, val stopReason: String?)

interface LlmProvider {
    suspend fun complete(system: String, history: List<ChatMsg>, tools: List<ToolDef>): LlmResponse

    /** IDs of the models this provider/key can use. */
    suspend fun listModels(): List<String>
}

suspend fun httpGetJson(req: Request): JsonObject = withContext(Dispatchers.IO) {
    Http.client.newCall(req).await().use { r ->
        val s = r.body?.string().orEmpty()
        if (!r.isSuccessful) throw LlmException("HTTP ${r.code}: ${s.take(500)}")
        AppJson.parseToJsonElement(s).jsonObject
    }
}

fun JsonObject.modelIds(): List<String> =
    (this["data"] as? JsonArray)?.mapNotNull { (it as? JsonObject)?.str("id") } ?: emptyList()

class LlmException(message: String) : Exception(message)

val AppJson = Json { ignoreUnknownKeys = true; encodeDefaults = true; isLenient = true }
val PrettyJson = Json { prettyPrint = true }

fun JsonObject.str(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull

object Http {
    val JSON = "application/json; charset=utf-8".toMediaType()

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.MINUTES)
        .writeTimeout(2, TimeUnit.MINUTES)
        .build()

    /** Only used for control panels the user explicitly marked as having a self-signed certificate. */
    val insecureClient: OkHttpClient by lazy {
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ssl = SSLContext.getInstance("TLS")
        ssl.init(null, arrayOf<TrustManager>(tm), SecureRandom())
        client.newBuilder()
            .sslSocketFactory(ssl.socketFactory, tm)
            .hostnameVerifier { _, _ -> true }
            .build()
    }

    fun clientFor(insecure: Boolean): OkHttpClient = if (insecure) insecureClient else client
}

/** Cancellable OkHttp call: pressing "Stop" aborts the in-flight request. */
suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (!cont.isCancelled) cont.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            cont.resume(response)
        }
    })
    cont.invokeOnCancellation { runCatching { cancel() } }
}

fun parseHeaderLines(s: String): List<Pair<String, String>> = s.lines().mapNotNull { line ->
    val i = line.indexOf(':')
    if (i <= 0) null else line.substring(0, i).trim() to line.substring(i + 1).trim()
}
