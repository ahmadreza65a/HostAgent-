package com.hostagent.app.llm

import com.hostagent.app.data.ProviderConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/** Claude via the Anthropic Messages API (also works with Anthropic-compatible proxies). */
class AnthropicProvider(private val cfg: ProviderConfig) : LlmProvider {

    private val official = cfg.baseUrl.isBlank() || cfg.baseUrl.contains("anthropic.com")

    private fun endpoint(): String {
        val base = cfg.baseUrl.ifBlank { "https://api.anthropic.com" }.trim().trimEnd('/')
        return when {
            base.endsWith("/messages") -> base
            base.endsWith("/v1") -> "$base/messages"
            else -> "$base/v1/messages"
        }
    }

    override suspend fun listModels(): List<String> {
        val base = endpoint().removeSuffix("/messages")
        val req = Request.Builder().url("$base/models?limit=1000")
            .header("x-api-key", cfg.apiKey)
            .header("anthropic-version", "2023-06-01")
        parseHeaderLines(cfg.extraHeaders).forEach { (k, v) -> req.header(k, v) }
        return httpGetJson(req.build()).modelIds()
    }

    override suspend fun complete(system: String, history: List<ChatMsg>, tools: List<ToolDef>): LlmResponse {
        val body = buildJsonObject {
            put("model", cfg.model)
            put("max_tokens", cfg.maxTokens)
            if (official) {
                // Prompt caching: tools + system prompt are cached between agent steps (cheaper and faster).
                putJsonArray("system") {
                    addJsonObject {
                        put("type", "text"); put("text", system)
                        putJsonObject("cache_control") { put("type", "ephemeral") }
                    }
                }
            } else {
                put("system", system)
            }
            if (tools.isNotEmpty()) putJsonArray("tools") {
                tools.forEach { t ->
                    addJsonObject {
                        put("name", t.name); put("description", t.description); put("input_schema", t.schema)
                    }
                }
            }
            put("messages", buildMessages(history))
        }

        val req = Request.Builder()
            .url(endpoint())
            .post(body.toString().toRequestBody(Http.JSON))
            .header("x-api-key", cfg.apiKey)
            .header("anthropic-version", "2023-06-01")
        parseHeaderLines(cfg.extraHeaders).forEach { (k, v) -> req.header(k, v) }

        val raw = withContext(Dispatchers.IO) {
            Http.client.newCall(req.build()).await().use { resp ->
                val s = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw LlmException("HTTP ${resp.code}: ${s.take(1500)}")
                s
            }
        }

        val root = AppJson.parseToJsonElement(raw).jsonObject
        val text = StringBuilder()
        val calls = mutableListOf<ToolCall>()
        root["content"]?.jsonArray?.forEach { el ->
            val b = el.jsonObject
            when (b.str("type")) {
                "text" -> text.append(b.str("text").orEmpty())
                "tool_use" -> calls.add(
                    ToolCall(
                        id = b.str("id") ?: "toolu_${System.nanoTime()}",
                        name = b.str("name").orEmpty(),
                        input = b["input"] as? JsonObject ?: JsonObject(emptyMap())
                    )
                )
            }
        }
        return LlmResponse(text.toString(), calls, root.str("stop_reason"))
    }

    private fun textBlock(t: String) = buildJsonObject { put("type", "text"); put("text", t.ifBlank { "..." }) }

    private fun buildMessages(history: List<ChatMsg>): JsonArray {
        // Merge consecutive same-role turns (e.g. tool results followed by a new user message).
        val turns = mutableListOf<Pair<String, MutableList<JsonObject>>>()
        fun push(role: String, blocks: List<JsonObject>) {
            if (turns.isNotEmpty() && turns.last().first == role) turns.last().second.addAll(blocks)
            else turns.add(role to blocks.toMutableList())
        }
        for (m in history) when (m) {
            is ChatMsg.User -> push("user", m.images.map { img ->
                buildJsonObject {
                    put("type", "image")
                    putJsonObject("source") {
                        put("type", "base64"); put("media_type", img.mediaType); put("data", img.base64)
                    }
                }
            } + if (m.text.isNotBlank() || m.images.isEmpty()) listOf(textBlock(m.text)) else emptyList())
            is ChatMsg.Assistant -> {
                val blocks = mutableListOf<JsonObject>()
                if (m.text.isNotBlank()) blocks.add(textBlock(m.text))
                m.toolCalls.forEach { c ->
                    blocks.add(buildJsonObject {
                        put("type", "tool_use"); put("id", c.id); put("name", c.name); put("input", c.input)
                    })
                }
                if (blocks.isEmpty()) blocks.add(textBlock("(no output)"))
                push("assistant", blocks)
            }
            is ChatMsg.Tools -> push("user", m.results.map { r ->
                buildJsonObject {
                    put("type", "tool_result")
                    put("tool_use_id", r.toolCallId)
                    put("content", r.content.ifEmpty { "(empty)" })
                    if (r.isError) put("is_error", true)
                }
            })
        }
        // Cache breakpoint on the newest block so each agent step reuses the previous prefix.
        if (official && turns.isNotEmpty()) {
            val last = turns.last().second
            val lb = last.last()
            last[last.lastIndex] = JsonObject(lb + ("cache_control" to buildJsonObject { put("type", "ephemeral") }))
        }
        return buildJsonArray {
            turns.forEach { (role, blocks) ->
                addJsonObject { put("role", role); put("content", JsonArray(blocks)) }
            }
        }
    }
}
