@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.hostagent.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hostagent.app.data.FileProtocol
import com.hostagent.app.data.HostConfig
import com.hostagent.app.data.PanelType

@Composable
fun HostsScreen(vm: MainViewModel) {
    var editing by remember { mutableStateOf<HostConfig?>(null) }
    var creating by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TopAppBar(title = { Text("هاست‌ها و سرورها") })
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (vm.hosts.isEmpty()) item {
                    Text("هاستی اضافه نشده. با + یک هاست سی‌پنل، دایرکت‌ادمین یا هر سرور FTP/SFTP اضافه کنید.", Modifier.padding(8.dp))
                }
                items(vm.hosts, key = { it.id }) { h ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(h.name, fontWeight = FontWeight.SemiBold)
                                CodeText("${h.protocol} ${h.host}:${h.port}  ${h.remoteRoot}", maxLines = 1)
                                if (h.panelType != PanelType.NONE) CodeText("${h.panelType}  ${h.panelUrl}", maxLines = 1)
                            }
                            IconButton(onClick = { editing = h }) { Icon(Icons.Filled.Edit, "ویرایش") }
                            IconButton(onClick = { vm.deleteHost(h) }) { Icon(Icons.Filled.Delete, "حذف") }
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { creating = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Filled.Add, "افزودن") }
    }

    if (creating || editing != null) {
        HostDialog(
            vm = vm,
            initial = editing,
            onDismiss = { creating = false; editing = null },
            onSave = { vm.upsertHost(it); creating = false; editing = null }
        )
    }
}

private fun defaultPort(p: FileProtocol) = when (p) { FileProtocol.SFTP -> 22; else -> 21 }
private fun defaultPanelPort(p: PanelType) = when (p) { PanelType.CPANEL -> 2083; PanelType.DIRECTADMIN -> 2222; else -> 0 }

@Composable
private fun HostDialog(vm: MainViewModel, initial: HostConfig?, onDismiss: () -> Unit, onSave: (HostConfig) -> Unit) {
    var h by remember { mutableStateOf(initial ?: HostConfig()) }
    var port by remember { mutableStateOf(h.port.toString()) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }

    fun current() = h.copy(port = port.toIntOrNull() ?: defaultPort(h.protocol), name = h.name.ifBlank { h.host })

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "هاست جدید" else "ویرایش هاست") },
        text = {
            Column(Modifier.heightIn(max = 580.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("نام (مثلاً mysite)", h.name, { h = h.copy(name = it) })
                Field("توضیح برای ایجنت (اختیاری) — مثلاً: وردپرس، دامنه mysite.com", h.notes, { h = h.copy(notes = it) }, singleLine = false, ltr = false)

                HorizontalDivider()
                Text("دسترسی به فایل‌ها", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FileProtocol.entries.forEach { pr ->
                        FilterChip(selected = h.protocol == pr, onClick = {
                            if (port == defaultPort(h.protocol).toString() || port.isBlank()) port = defaultPort(pr).toString()
                            h = h.copy(protocol = pr)
                        }, label = { Text(if (pr == FileProtocol.NONE) "هیچ" else pr.name) })
                    }
                }
                if (h.protocol != FileProtocol.NONE) {
                    Field("آدرس سرور (ftp.example.com یا IP)", h.host, { h = h.copy(host = it.trim()) })
                    Field("پورت", port, { port = it.filter(Char::isDigit) }, number = true)
                    Field("نام کاربری", h.username, { h = h.copy(username = it.trim()) })
                    Field(
                        if (h.protocol == FileProtocol.SFTP) "رمز عبور یا کلید خصوصی SSH" else "رمز عبور",
                        h.password, { h = h.copy(password = it) },
                        secret = h.protocol != FileProtocol.SFTP || !h.password.startsWith("-----"),
                        singleLine = h.protocol != FileProtocol.SFTP
                    )
                    Field("پوشه ریشه (مثلاً /public_html یا /domains/site.com/public_html)", h.remoteRoot, { h = h.copy(remoteRoot = it.trim()) })
                }

                HorizontalDivider()
                Text("API کنترل‌پنل (اختیاری)", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PanelType.entries.forEach { pt ->
                        FilterChip(selected = h.panelType == pt, onClick = {
                            var url = h.panelUrl
                            if (url.isBlank() && pt != PanelType.NONE && h.host.isNotBlank()) {
                                url = "https://${h.host.removePrefix("ftp.")}:${defaultPanelPort(pt)}"
                            }
                            h = h.copy(panelType = pt, panelUrl = url, panelUser = h.panelUser.ifBlank { h.username })
                        }, label = {
                            Text(when (pt) { PanelType.NONE -> "هیچ"; PanelType.CPANEL -> "cPanel"; PanelType.DIRECTADMIN -> "DirectAdmin" })
                        })
                    }
                }
                if (h.panelType != PanelType.NONE) {
                    Field("آدرس پنل", h.panelUrl, { h = h.copy(panelUrl = it.trim()) })
                    Field("نام کاربری پنل", h.panelUser, { h = h.copy(panelUser = it.trim()) })
                    if (h.panelType == PanelType.CPANEL) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = h.panelUseToken, onCheckedChange = { h = h.copy(panelUseToken = it) })
                            Text("استفاده از API Token (پیشنهادی)")
                        }
                    }
                    Field(
                        when {
                            h.panelType == PanelType.CPANEL && h.panelUseToken -> "API Token سی‌پنل"
                            h.panelType == PanelType.DIRECTADMIN -> "رمز یا Login Key دایرکت‌ادمین"
                            else -> "رمز عبور پنل"
                        },
                        h.panelSecret, { h = h.copy(panelSecret = it.trim()) }, secret = true
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = h.insecureTls, onCheckedChange = { h = h.copy(insecureTls = it) })
                        Text("پذیرش گواهی SSL خودامضا", style = MaterialTheme.typography.bodySmall)
                    }
                }

                OutlinedButton(onClick = {
                    testing = true; testResult = null
                    vm.testHost(current()) { testResult = it; testing = false }
                }, enabled = !testing) { Text(if (testing) "در حال تست…" else "تست اتصال") }
                testResult?.let { CodeText(it) }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(current()) }, enabled = h.host.isNotBlank() || h.panelUrl.isNotBlank()) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
