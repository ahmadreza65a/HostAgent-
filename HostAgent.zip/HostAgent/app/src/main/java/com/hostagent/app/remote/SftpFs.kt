package com.hostagent.app.remote

import com.hostagent.app.data.HostConfig
import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.SftpException
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream

/** SFTP over SSH. The password field may contain a private key (PEM/OpenSSH) instead of a password. */
class SftpFs(private val h: HostConfig) : RemoteFs {

    private val session: Session
    private val ch: ChannelSftp

    init {
        val jsch = JSch()
        val secret = h.password.trim()
        val isKey = secret.startsWith("-----BEGIN")
        if (isKey) jsch.addIdentity("key", secret.toByteArray(), null, null)
        session = jsch.getSession(h.username, h.host.trim(), if (h.port > 0) h.port else 22)
        if (!isKey) session.setPassword(h.password)
        session.setConfig("StrictHostKeyChecking", "no")
        session.connect(20_000)
        ch = session.openChannel("sftp") as ChannelSftp
        ch.connect(20_000)
    }

    override fun list(path: String): List<RemoteEntry> =
        (ch.ls(path) as java.util.Vector<*>).mapNotNull { it as? ChannelSftp.LsEntry }
            .filter { it.filename != "." && it.filename != ".." }
            .map { RemoteEntry(it.filename, it.attrs.isDir, it.attrs.size, it.attrs.mtimeString) }

    override fun read(path: String): ByteArray = ch.get(path).use { it.readBytes() }

    override fun write(path: String, data: ByteArray) {
        mkdirs(RemotePath.parent(path))
        ch.put(ByteArrayInputStream(data), path)
    }

    override fun mkdirs(path: String) {
        var cur = ""
        for (seg in path.split('/').filter { it.isNotEmpty() }) {
            cur += "/$seg"
            try { ch.stat(cur) } catch (e: SftpException) { ch.mkdir(cur) }
        }
    }

    override fun delete(path: String) {
        val st = ch.stat(path)
        if (st.isDir) {
            list(path).forEach { delete("$path/${it.name}") }
            ch.rmdir(path)
        } else {
            ch.rm(path)
        }
    }

    override fun rename(from: String, to: String) {
        mkdirs(RemotePath.parent(to))
        ch.rename(from, to)
    }

    /** Run a shell command over SSH (only available for SFTP hosts with shell access). */
    fun exec(command: String, timeoutMs: Long = 120_000): String {
        val exec = session.openChannel("exec") as ChannelExec
        val out = ByteArrayOutputStream()
        val err = ByteArrayOutputStream()
        exec.setCommand(command)
        exec.setOutputStream(out)
        exec.setErrStream(err)
        exec.connect(20_000)
        val start = System.currentTimeMillis()
        while (!exec.isClosed && System.currentTimeMillis() - start < timeoutMs) Thread.sleep(150)
        val code = exec.exitStatus
        exec.disconnect()
        return buildString {
            append("exit code: $code\n")
            if (out.size() > 0) append(out.toString(Charsets.UTF_8.name()))
            if (err.size() > 0) append("\n[stderr]\n").append(err.toString(Charsets.UTF_8.name()))
        }
    }

    override fun close() {
        runCatching { ch.disconnect() }
        runCatching { session.disconnect() }
    }
}
