@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.hostagent.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hostagent.app.data.CLAUDE_MODELS
import com.hostagent.app.data.PROVIDER_PRESETS
import com.hostagent.app.data.ProviderConfig
import com.hostagent.app.data.ProviderType
import java.util.UUID

@Composable
fun ProvidersScreen(vm: MainViewModel) {
    var editing by remember { mutableStateOf<ProviderConfig?>(null) }
    var creating by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TopAppBar(title = { Text("پرووایدرهای هوش مصنوعی") })
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (vm.providers.isEmpty()) item {
                    Text("هنوز پرووایدری اضافه نشده. با دکمه + یک پرووایدر (مثلاً Claude) اضافه کنید.", Modifier.padding(8.dp))
                }
                items(vm.providers, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = vm.selectedProvider?.id == p.id, onClick = { vm.selectProvider(p.id) })
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.SemiBold)
                                Text(p.type.label, style = MaterialTheme.typography.bodySmall)
                                CodeText("${p.model}  ·  ${p.baseUrl}", maxLines = 1)
                            }
                            IconButton(onClick = { editing = p }) { Icon(Icons.Filled.Edit, "ویرایش") }
                            IconButton(onClick = { vm.deleteProvider(p) }) { Icon(Icons.Filled.Delete, "حذف") }
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { creating = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Filled.Add, "افزودن") }
    }

    if (creating || editing != null) {
        ProviderDialog(
            vm = vm,
            initial = editing,
            onDismiss = { creating = false; editing = null },
            onSave = { vm.upsertProvider(it); creating = false; editing = null }
        )
    }
}

@Composable
private fun ProviderDialog(vm: MainViewModel, initial: ProviderConfig?, onDismiss: () -> Unit, onSave: (ProviderConfig) -> Unit) {
    var p by remember { mutableStateOf(initial ?: PROVIDER_PRESETS.first().copy(id = UUID.randomUUID().toString())) }
    var maxTokens by remember { mutableStateOf(p.maxTokens.toString()) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    var models by remember { mutableStateOf<List<String>>(emptyList()) }
    var modelsMsg by remember { mutableStateOf<String?>(null) }

    fun current() = p.copy(maxTokens = maxTokens.toIntOrNull() ?: 8192)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "پرووایدر جدید" else "ویرایش پرووایدر") },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (initial == null) {
                    Text("الگوی آماده:", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PROVIDER_PRESETS.forEach { preset ->
                            AssistChip(onClick = {
                                p = preset.copy(id = p.id, apiKey = p.apiKey)
                                maxTokens = preset.maxTokens.toString()
                            }, label = { Text(preset.name) })
                        }
                    }
                }
                Text("نوع API:", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ProviderType.entries.forEach { t ->
                        FilterChip(selected = p.type == t, onClick = { p = p.copy(type = t) }, label = { Text(t.label) })
                    }
                }
                Field("نام", p.name, { p = p.copy(name = it) }, ltr = false)
                Field("آدرس پایه (Base URL)", p.baseUrl, { p = p.copy(baseUrl = it) })
                Text(
                    if (p.type == ProviderType.ANTHROPIC) "مثال: https://api.anthropic.com" else "مثال: https://api.openai.com/v1  (بدون /chat/completions)",
                    style = MaterialTheme.typography.bodySmall
                )
                Field("کلید API", p.apiKey, { p = p.copy(apiKey = it) }, secret = true)
                Field("مدل", p.model, { p = p.copy(model = it) })
                if (p.type == ProviderType.ANTHROPIC && models.isEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CLAUDE_MODELS.forEach { m -> AssistChip(onClick = { p = p.copy(model = m) }, label = { Text(m) }) }
                }
                OutlinedButton(onClick = {
                    modelsMsg = "در حال دریافت…"
                    vm.fetchModels(current()) { r ->
                        r.onSuccess {
                            models = it
                            modelsMsg = if (it.isEmpty()) "پرووایدر لیستی برنگرداند؛ نام مدل را دستی وارد کنید." else null
                        }.onFailure { modelsMsg = "❌ ${it.message}" }
                    }
                }, enabled = p.baseUrl.isNotBlank()) { Text("دریافت لیست مدل‌ها از پرووایدر") }
                modelsMsg?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                if (models.isNotEmpty()) {
                    // The model field doubles as a search box: type "claude", "coder", "pro"... to filter.
                    val shown = models.filter { p.model.isBlank() || it.contains(p.model, ignoreCase = true) || p.model in models }.take(40)
                    Text(
                        "${models.size} مدل در دسترس — با تایپ در فیلد «مدل» جستجو کنید، روی مدل بزنید تا انتخاب شود:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        shown.forEach { m ->
                            FilterChip(selected = p.model == m, onClick = { p = p.copy(model = m) }, label = { Text(m) })
                        }
                    }
                }
                Field("حداکثر توکن خروجی", maxTokens, { maxTokens = it.filter(Char::isDigit) }, number = true)
                Field("هدرهای اضافه (هر خط: Name: value)", p.extraHeaders, { p = p.copy(extraHeaders = it) }, singleLine = false)

                OutlinedButton(onClick = {
                    testing = true; testResult = null
                    vm.testProvider(current()) { testResult = it; testing = false }
                }, enabled = !testing) { Text(if (testing) "در حال تست…" else "تست اتصال") }
                testResult?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                Spacer(Modifier.size(4.dp))
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(current().let { if (it.name.isBlank()) it.copy(name = it.model) else it }) },
                enabled = p.baseUrl.isNotBlank() && p.model.isNotBlank()
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
