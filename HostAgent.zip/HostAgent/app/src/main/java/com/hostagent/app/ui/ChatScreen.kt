@file:OptIn(ExperimentalMaterial3Api::class)

package com.hostagent.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hostagent.app.llm.ToolCall

@Composable
fun ChatScreen(vm: MainViewModel) {
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(vm.items.size, vm.items.lastOrNull()) {
        if (vm.items.isNotEmpty()) listState.animateScrollToItem(vm.items.size - 1)
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { ProviderPicker(vm) },
            actions = {
                IconButton(onClick = { vm.newChat() }) { Icon(Icons.Filled.AddComment, contentDescription = "گفتگوی جدید") }
            }
        )
        if (vm.thinking) LinearProgressIndicator(Modifier.fillMaxWidth())

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (vm.items.isEmpty()) item { EmptyHint(vm) }
            items(vm.items, key = { it.key }) { ChatItemView(it) }
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("دستور خود را بنویسید…") },
                maxLines = 6
            )
            Spacer(Modifier.width(8.dp))
            if (vm.running) {
                FilledIconButton(onClick = { vm.stop() }) { Icon(Icons.Filled.Stop, contentDescription = "توقف") }
            } else {
                FilledIconButton(
                    onClick = { if (input.isNotBlank()) { vm.send(input.trim()); input = "" } },
                    enabled = input.isNotBlank()
                ) { Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "ارسال") }
            }
        }
    }

    vm.pendingApproval?.let { ApprovalDialog(it, vm) }
}

@Composable
private fun ProviderPicker(vm: MainViewModel) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }) {
            Text(
                vm.selectedProvider?.let { "${it.name} · ${it.model}" } ?: "انتخاب پرووایدر",
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (vm.providers.isEmpty()) DropdownMenuItem(text = { Text("پرووایدری اضافه نشده") }, onClick = { open = false })
            vm.providers.forEach { p ->
                DropdownMenuItem(
                    text = { Text("${p.name} (${p.model})") },
                    onClick = { vm.selectProvider(p.id); open = false }
                )
            }
        }
    }
}

@Composable
private fun EmptyHint(vm: MainViewModel) {
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("HostAgent", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.size(8.dp))
        Text(
            "پرووایدرها: ${vm.providers.size} · هاست‌ها: ${vm.hosts.size}\n\n" +
                "نمونه دستورها:\n" +
                "• فایل‌های public_html هاست من را بررسی کن و بگو چه سایتی رویش است\n" +
                "• یک صفحه فرود ریسپانسیو با فرم تماس PHP بساز و روی هاست آپلود کن\n" +
                "• یک دیتابیس MySQL جدید در سی‌پنل بساز\n" +
                "• خطای 500 سایتم را پیدا و رفع کن",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun ChatItemView(item: UiItem) {
    when (item) {
        is UiItem.User -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(14.dp), modifier = Modifier.widthIn(max = 340.dp)) {
                SelectionContainer { Text(item.text, Modifier.padding(12.dp)) }
            }
        }

        is UiItem.Assistant -> Surface(
            color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
        ) {
            SelectionContainer { Text(item.text, Modifier.padding(12.dp)) }
        }

        is UiItem.Tool -> ToolCard(item)

        is UiItem.Info -> Text(
            item.text,
            color = if (item.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
        )
    }
}

@Composable
private fun ToolCard(item: UiItem.Tool) {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().clickable { expanded = !expanded }) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                when {
                    item.result == null -> CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    item.result.isError -> Icon(Icons.Filled.Error, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    else -> Icon(Icons.Filled.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Filled.Build, null, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Ltr { Text(item.call.name, fontWeight = FontWeight.SemiBold) }
            }
            Spacer(Modifier.size(4.dp))
            val summary = listOfNotNull(
                item.call.input["host"], item.call.input["path"], item.call.input["endpoint"],
                item.call.input["url"], item.call.input["command"], item.call.input["from"]
            ).joinToString("  ") { it.toString().trim('"') }
            if (summary.isNotBlank()) CodeText(summary, maxLines = 2)
            if (expanded) {
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Text("ورودی:", style = MaterialTheme.typography.labelSmall)
                SelectionContainer { CodeText(pretty(item.call.input).take(6000)) }
                item.result?.let {
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    Text("نتیجه:", style = MaterialTheme.typography.labelSmall)
                    SelectionContainer { CodeText(it.content.take(12000)) }
                }
            } else if (item.result != null) {
                CodeText(item.result.content.lineSequence().firstOrNull().orEmpty().take(140), maxLines = 1)
            }
        }
    }
}

@Composable
private fun ApprovalDialog(call: ToolCall, vm: MainViewModel) {
    AlertDialog(
        onDismissRequest = {},
        title = { Text("اجازه اجرای «${call.name}»؟") },
        text = {
            Column {
                Text("ایجنت می‌خواهد این عملیات را روی هاست انجام دهد:", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.size(8.dp))
                Box(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    CodeText(pretty(call.input).take(20000))
                }
                TextButton(onClick = { vm.answerApproval(allow = true, always = true) }) {
                    Text("اجازه برای همه عملیات‌های این گفتگو")
                }
            }
        },
        confirmButton = { Button(onClick = { vm.answerApproval(true) }) { Text("اجازه") } },
        dismissButton = { TextButton(onClick = { vm.answerApproval(false) }) { Text("رد") } }
    )
}
