package com.hostagent.app.data

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
enum class ProviderType(val label: String) {
    ANTHROPIC("Anthropic (Claude)"),
    OPENAI_COMPATIBLE("OpenAI-compatible / Custom")
}

@Serializable
data class ProviderConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val type: ProviderType = ProviderType.ANTHROPIC,
    /** Anthropic: https://api.anthropic.com   |   OpenAI-compatible: https://host/v1 */
    val baseUrl: String = "",
    val apiKey: String = "",
    val model: String = "",
    val maxTokens: Int = 8192,
    /** Extra HTTP headers, one per line: "Header-Name: value" */
    val extraHeaders: String = ""
)

@Serializable
enum class FileProtocol { FTP, FTPS, SFTP, NONE }

@Serializable
enum class PanelType { NONE, CPANEL, DIRECTADMIN }

@Serializable
data class HostConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    // --- file access ---
    val protocol: FileProtocol = FileProtocol.FTP,
    val host: String = "",
    val port: Int = 21,
    val username: String = "",
    /** Password, or for SFTP a full private key (-----BEGIN ... KEY-----) */
    val password: String = "",
    val remoteRoot: String = "/public_html",
    // --- control panel API ---
    val panelType: PanelType = PanelType.NONE,
    /** e.g. https://example.com:2083 (cPanel) or https://example.com:2222 (DirectAdmin) */
    val panelUrl: String = "",
    val panelUser: String = "",
    /** cPanel API token / password, or DirectAdmin password / login key */
    val panelSecret: String = "",
    /** cPanel: true = "Authorization: cpanel user:TOKEN", false = Basic auth with password */
    val panelUseToken: Boolean = true,
    /** Accept self-signed TLS certificates for the panel API */
    val insecureTls: Boolean = false,
    val notes: String = ""
)

@Serializable
data class AppSettings(
    val requireApproval: Boolean = true,
    val maxSteps: Int = 40,
    val customInstructions: String = ""
)

val PROVIDER_PRESETS = listOf(
    ProviderConfig(name = "Claude", type = ProviderType.ANTHROPIC, baseUrl = "https://api.anthropic.com", model = "claude-sonnet-5-5", maxTokens = 16000),
    ProviderConfig(name = "OpenAI", type = ProviderType.OPENAI_COMPATIBLE, baseUrl = "https://api.openai.com/v1", model = "gpt-4.1"),
    ProviderConfig(name = "OpenRouter", type = ProviderType.OPENAI_COMPATIBLE, baseUrl = "https://openrouter.ai/api/v1", model = "anthropic/claude-sonnet-4.5"),
    ProviderConfig(name = "DeepSeek", type = ProviderType.OPENAI_COMPATIBLE, baseUrl = "https://api.deepseek.com/v1", model = "deepseek-chat"),
    ProviderConfig(name = "Gemini", type = ProviderType.OPENAI_COMPATIBLE, baseUrl = "https://generativelanguage.googleapis.com/v1beta/openai", model = "gemini-2.5-pro"),
    ProviderConfig(name = "Custom", type = ProviderType.OPENAI_COMPATIBLE, baseUrl = "https://", model = "")
)

val CLAUDE_MODELS = listOf("claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5")
