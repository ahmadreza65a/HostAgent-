package com.hostagent.app.llm

import com.hostagent.app.data.ProviderConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.UUID

/**
 * Any provider that speaks the OpenAI Chat Completions format with function calling:
 * OpenAI, OpenRouter, DeepSeek, Gemini (OpenAI endpoint), Groq, Together, Ollama, LM Studio, vLLM, custom gateways...
 */
class OpenAICompatProvider(private val cfg: ProviderConfig) : LlmProvider {

    private fun endpoint(): String {
        val base = cfg.baseUrl.trim().trimEnd('/')
        return if (base.endsWith("/chat/completions")) base else "$base/chat/completions"
    }

    override suspend fun listModels(): List<String> {
        val base = cfg.baseUrl.trim().trimEnd('/').removeSuffix("/chat/completions")
        val req = Request.Builder().url("$base/models")
        if (cfg.apiKey.isNotBlank()) req.header("Authorization", "Bearer ${cfg.apiKey}")
        parseHeaderLines(cfg.extraHeaders).forEach { (k, v) -> req.header(k, v) }
        return httpGetJson(req.build()).modelIds()
    }

    override suspend fun complete(system: String, history: List<ChatMsg>, tools: List<ToolDef>): LlmResponse {
        val body = buildJsonObject {
            put("model", cfg.model)
            put("max_tokens", cfg.maxTokens)
            putJsonArray("messages") {
                addJsonObject { put("role", "system"); put("content", system) }
                for (m in history) when (m) {
                    is ChatMsg.User -> addJsonObject {
                        put("role", "user")
                        if (m.images.isEmpty()) put("content", m.text)
                        else putJsonArray("content") {
                            if (m.text.isNotBlank()) addJsonObject { put("type", "text"); put("text", m.text) }
                            m.images.forEach { img ->
                                addJsonObject {
                                    put("type", "image_url")
                                    putJsonObject("image_url") { put("url", "data:${img.mediaType};base64,${img.base64}") }
                                }
                            }
                        }
                    }
                    is ChatMsg.Assistant -> addJsonObject {
                        put("role", "assistant")
                        if (m.text.isBlank()) put("content", JsonNull) else put("content", m.text)
                        if (m.toolCalls.isNotEmpty()) putJsonArray("tool_calls") {
                            m.toolCalls.forEach { c ->
                                addJsonObject {
                                    put("id", c.id); put("type", "function")
                                    putJsonObject("function") { put("name", c.name); put("arguments", c.input.toString()) }
                                }
                            }
                        }
                    }
                    is ChatMsg.Tools -> m.results.forEach { r ->
                        addJsonObject {
                            put("role", "tool"); put("tool_call_id", r.toolCallId)
                            put("content", if (r.isError) "ERROR: ${r.content}" else r.content)
                        }
                    }
                }
            }
            if (tools.isNotEmpty()) putJsonArray("tools") {
                tools.forEach { t ->
                    addJsonObject {
                        put("type", "function")
                        putJsonObject("function") {
                            put("name", t.name); put("description", t.description); put("parameters", t.schema)
                        }
                    }
                }
            }
        }

        val req = Request.Builder()
            .url(endpoint())
            .post(body.toString().toRequestBody(Http.JSON))
        if (cfg.apiKey.isNotBlank()) req.header("Authorization", "Bearer ${cfg.apiKey}")
        parseHeaderLines(cfg.extraHeaders).forEach { (k, v) -> req.header(k, v) }

        val raw = withContext(Dispatchers.IO) {
            Http.client.newCall(req.build()).await().use { resp ->
                val s = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw LlmException("HTTP ${resp.code}: ${s.take(1500)}")
                s
            }
        }

        val root = AppJson.parseToJsonElement(raw).jsonObject
        (root["error"] as? JsonObject)?.let { throw LlmException(it.str("message") ?: it.toString()) }
        val choice = (root["choices"] as? JsonArray)?.firstOrNull()?.jsonObject
            ?: throw LlmException("Unexpected response: ${raw.take(800)}")
        val msg = choice["message"]?.jsonObject ?: throw LlmException("No message in response")

        val content = when (val c = msg["content"]) {
            is JsonPrimitive -> c.contentOrNull.orEmpty()
            is JsonArray -> c.joinToString("") { (it as? JsonObject)?.str("text").orEmpty() }
            else -> ""
        }
        val calls = (msg["tool_calls"] as? JsonArray)?.mapNotNull { tc ->
            val o = tc.jsonObject
            val f = o["function"]?.jsonObject ?: return@mapNotNull null
            val args: JsonObject = when (val a = f["arguments"]) {
                is JsonObject -> a
                is JsonPrimitive -> {
                    val s = a.contentOrNull.orEmpty().ifBlank { "{}" }
                    runCatching { AppJson.parseToJsonElement(s).jsonObject }
                        .getOrElse { buildJsonObject { put("_raw", s) } }
                }
                else -> JsonObject(emptyMap())
            }
            ToolCall(o.str("id") ?: "call_${UUID.randomUUID()}", f.str("name").orEmpty(), args)
        } ?: emptyList()

        return LlmResponse(content, calls, choice.str("finish_reason"))
    }
}
