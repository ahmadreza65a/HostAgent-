package com.hostagent.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.hostagent.app.llm.ImageData
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

object ImageUtil {

    /**
     * Loads an image/screenshot, downsizes it so the long edge is at most [maxDim] px
     * (models don't need more, and it keeps requests small), and encodes it as JPEG base64.
     * Returns the encoded image and a small thumbnail for the UI.
     */
    fun load(context: Context, uri: Uri, maxDim: Int = 1568): Pair<ImageData, Bitmap> {
        val cr = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: throw IllegalArgumentException("Cannot open image")
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxDim) sample *= 2

        val decoded = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: throw IllegalArgumentException("Cannot decode image")

        val scale = min(1f, maxDim.toFloat() / max(decoded.width, decoded.height))
        val bmp = if (scale < 1f) {
            Bitmap.createScaledBitmap(decoded, (decoded.width * scale).toInt(), (decoded.height * scale).toInt(), true)
        } else decoded

        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        val data = ImageData("image/jpeg", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))

        val tScale = min(1f, 256f / max(bmp.width, bmp.height))
        val thumb = Bitmap.createScaledBitmap(bmp, max(1, (bmp.width * tScale).toInt()), max(1, (bmp.height * tScale).toInt()), true)
        return data to thumb
    }
}
