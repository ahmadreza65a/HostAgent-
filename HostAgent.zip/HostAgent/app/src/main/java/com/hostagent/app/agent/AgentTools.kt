package com.hostagent.app.agent

import android.content.Context
import com.hostagent.app.data.FileProtocol
import com.hostagent.app.data.HostConfig
import com.hostagent.app.llm.Http
import com.hostagent.app.llm.ToolCall
import com.hostagent.app.llm.ToolDef
import com.hostagent.app.llm.ToolResult
import com.hostagent.app.llm.str
import com.hostagent.app.remote.PanelApi
import com.hostagent.app.remote.RemoteFs
import com.hostagent.app.remote.RemoteFsFactory
import com.hostagent.app.remote.RemotePath
import com.hostagent.app.remote.SftpFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** All tools the agent can call. Each call opens a fresh connection, so nothing stays connected in the background. */
class AgentTools(context: Context, private val hosts: () -> List<HostConfig>) {

    val workspace: File = File(context.filesDir, "workspace").apply { mkdirs() }.canonicalFile

    private companion object {
        const val MAX_READ = 200_000
        const val MAX_OUT = 80_000
        val APPROVAL = setOf(
            "remote_write", "remote_edit", "remote_delete", "remote_rename",
            "remote_upload_local", "panel_api", "ssh_exec"
        )
    }

    fun needsApproval(name: String) = name in APPROVAL

    // ---------------------------------------------------------------- definitions

    private data class P(val name: String, val type: String, val desc: String, val required: Boolean = true)

    private fun def(name: String, desc: String, vararg ps: P) = ToolDef(name, desc, buildJsonObject {
        put("type", "object")
        putJsonObject("properties") {
            ps.forEach { p -> putJsonObject(p.name) { put("type", p.type); put("description", p.desc) } }
        }
        putJsonArray("required") { ps.filter { it.required }.forEach { add(it.name) } }
    })

    private val hostP = P(
        "host", "string",
        "Host name exactly as configured (see list_hosts). May be omitted when only one host is configured.",
        required = false
    )
    private val pathP = P("path", "string", "Path relative to the host root (e.g. 'index.php', 'wp-content/themes'), or absolute if it starts with '/'.")

    val definitions: List<ToolDef> = listOf(
        def("list_hosts", "List the hosting accounts configured in the app (names, protocols, root folders, control panels)."),
        def("remote_list", "List files and folders in a directory on a host.", hostP, pathP.copy(required = false)),
        def("remote_read", "Read a text file from a host.", hostP, pathP),
        def(
            "remote_write", "Create or overwrite a file on a host with the given text content. Parent folders are created automatically.",
            hostP, pathP, P("content", "string", "Full file content.")
        ),
        def(
            "remote_edit", "Edit an existing file on a host by replacing an exact, unique snippet of text. Prefer this for small changes.",
            hostP, pathP,
            P("old_text", "string", "Exact text to find (must occur exactly once, unless replace_all is true)."),
            P("new_text", "string", "Replacement text."),
            P("replace_all", "boolean", "Replace every occurrence.", required = false)
        ),
        def("remote_mkdir", "Create a directory (and parents) on a host.", hostP, pathP),
        def("remote_delete", "Delete a file or a directory (recursively) on a host.", hostP, pathP),
        def(
            "remote_rename", "Rename or move a file/directory on a host.",
            hostP, P("from", "string", "Source path."), P("to", "string", "Destination path.")
        ),
        def(
            "remote_upload_local", "Upload a file from the local workspace to a host (works for binary files and zips).",
            hostP, P("local_path", "string", "Path inside the local workspace."), P("remote_path", "string", "Destination path on the host.")
        ),
        def(
            "remote_download_local", "Download a file from a host into the local workspace (e.g. for backups).",
            hostP, P("remote_path", "string", "Path on the host."), P("local_path", "string", "Destination path inside the local workspace.")
        ),
        def(
            "panel_api",
            "Call the host's control-panel API. cPanel: endpoint is a UAPI 'Module/function' such as 'Mysql/list_databases', " +
                "'Mysql/create_database', 'DomainInfo/list_domains', 'Email/list_pops', 'SSL/list_certs', 'Fileman/list_files'. " +
                "DirectAdmin: endpoint is a CMD_API command such as 'CMD_API_SHOW_DOMAINS', 'CMD_API_DATABASES', 'CMD_API_POP', " +
                "'CMD_API_SUBDOMAINS' (json=yes is added automatically).",
            hostP,
            P("endpoint", "string", "API endpoint, see description."),
            P("params", "object", "Key/value parameters (string values).", required = false),
            P("method", "string", "GET or POST (default GET). Use POST for actions that change things.", required = false)
        ),
        def(
            "ssh_exec", "Run a shell command over SSH on an SFTP host that has shell access (e.g. 'php -v', 'composer install', 'unzip x.zip').",
            hostP, P("command", "string", "Shell command."), P("timeout_seconds", "integer", "Default 120.", required = false)
        ),
        def("local_list", "List files in the local workspace (private scratch folder inside the app).", P("path", "string", "Folder path, default root.", required = false)),
        def("local_read", "Read a text file from the local workspace.", P("path", "string", "File path.")),
        def("local_write", "Write a text file into the local workspace.", P("path", "string", "File path."), P("content", "string", "Content.")),
        def("local_delete", "Delete a file or folder in the local workspace.", P("path", "string", "Path.")),
        def(
            "http_request", "Send an HTTP request, e.g. to verify a deployed website or call a web API.",
            P("url", "string", "Full URL."),
            P("method", "string", "GET, POST, PUT, DELETE, HEAD (default GET).", required = false),
            P("headers", "object", "Request headers.", required = false),
            P("body", "string", "Request body.", required = false)
        )
    )

    // ---------------------------------------------------------------- execution

    suspend fun execute(call: ToolCall): ToolResult = withContext(Dispatchers.IO) {
        try {
            val out = run(call.name, call.input)
            val trimmed = if (out.length > MAX_OUT) out.take(MAX_OUT) + "\n...[truncated, ${out.length} chars total]" else out
            ToolResult(call.id, trimmed)
        } catch (e: Throwable) {
            ToolResult(call.id, "ERROR: ${e.javaClass.simpleName}: ${e.message}", isError = true)
        }
    }

    private fun JsonObject.req(k: String): String = str(k) ?: throw IllegalArgumentException("Missing parameter '$k'")
    private fun JsonObject.bool(k: String): Boolean = str(k)?.toBooleanStrictOrNull() ?: false

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /** Finds the host leniently: exact name, id, domain/server address, partial match, or the only configured host. */
    private fun host(input: JsonObject): HostConfig {
        val list = hosts()
        if (list.isEmpty()) throw IllegalArgumentException("No hosts configured. Ask the user to add one in the Hosts tab.")
        val n = input.str("host")?.trim().orEmpty()
        if (n.isEmpty() && list.size == 1) return list.first()
        val k = norm(n)
        return list.firstOrNull { it.name.equals(n, ignoreCase = true) || it.id == n }
            ?: list.firstOrNull { k.isNotEmpty() && (norm(it.name) == k || norm(it.host) == k) }
            ?: list.firstOrNull {
                k.isNotEmpty() && listOf(it.name, it.host, it.notes, it.panelUrl).any { f ->
                    val nf = norm(f); nf.isNotEmpty() && (nf.contains(k) || k.contains(nf))
                }
            }
            ?: list.singleOrNull()
            ?: throw IllegalArgumentException(
                "Use one of these host names: ${list.joinToString { "\"${it.name}\"" }} (\"$n\" not found)"
            )
    }

    private fun rp(h: HostConfig, p: String?) = RemotePath.resolve(h.remoteRoot, p ?: "")

    private inline fun <T> fs(h: HostConfig, block: (RemoteFs) -> T): T = RemoteFsFactory.open(h).use(block)

    private fun local(path: String?): File {
        val f = File(workspace, (path ?: "").trimStart('/')).canonicalFile
        require(f.path.startsWith(workspace.canonicalPath)) { "Path escapes the workspace." }
        return f
    }

    private fun run(name: String, input: JsonObject): String = when (name) {
        "list_hosts" -> hosts().joinToString("\n") { h ->
            "- ${h.name}: files=${h.protocol}${if (h.protocol != FileProtocol.NONE) " (${h.host}:${h.port}, root ${h.remoteRoot})" else ""}" +
                ", panel=${h.panelType}${if (h.notes.isNotBlank()) ", notes: ${h.notes}" else ""}"
        }.ifEmpty { "No hosts configured. Ask the user to add one in the Hosts tab." }

        "remote_list" -> {
            val h = host(input); val p = rp(h, input.str("path"))
            val entries = fs(h) { it.list(p) }.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
            if (entries.isEmpty()) "$p is empty (or does not exist)."
            else "$p\n" + entries.joinToString("\n") { e ->
                if (e.isDir) "[dir]  ${e.name}/" else "[file] ${e.name}  (${e.size} B, ${e.modified})"
            }
        }

        "remote_read" -> {
            val h = host(input); val p = rp(h, input.req("path"))
            val text = fs(h) { it.read(p) }.toString(Charsets.UTF_8)
            if (text.length > MAX_READ) text.take(MAX_READ) + "\n...[file truncated, ${text.length} chars]" else text
        }

        "remote_write" -> {
            val h = host(input); val p = rp(h, input.req("path")); val c = input.req("content")
            fs(h) { it.write(p, c.toByteArray()) }
            "Wrote ${c.toByteArray().size} bytes to $p"
        }

        "remote_edit" -> {
            val h = host(input); val p = rp(h, input.req("path"))
            val old = input.req("old_text"); val new = input.req("new_text"); val all = input.bool("replace_all")
            fs(h) { f ->
                val text = f.read(p).toString(Charsets.UTF_8)
                val count = text.split(old).size - 1
                when {
                    count == 0 -> throw IllegalStateException("old_text not found in $p")
                    count > 1 && !all -> throw IllegalStateException("old_text occurs $count times in $p; make it unique or set replace_all")
                }
                f.write(p, (if (all) text.replace(old, new) else text.replaceFirst(old, new)).toByteArray())
                "Edited $p ($count replacement${if (count > 1) "s" else ""})"
            }
        }

        "remote_mkdir" -> { val h = host(input); val p = rp(h, input.req("path")); fs(h) { it.mkdirs(p) }; "Created $p" }
        "remote_delete" -> { val h = host(input); val p = rp(h, input.req("path")); fs(h) { it.delete(p) }; "Deleted $p" }
        "remote_rename" -> {
            val h = host(input); val a = rp(h, input.req("from")); val b = rp(h, input.req("to"))
            fs(h) { it.rename(a, b) }; "Renamed $a -> $b"
        }

        "remote_upload_local" -> {
            val h = host(input); val f = local(input.req("local_path")); val p = rp(h, input.req("remote_path"))
            require(f.isFile) { "Local file not found: ${input.req("local_path")}" }
            fs(h) { it.write(p, f.readBytes()) }; "Uploaded ${f.length()} bytes to $p"
        }

        "remote_download_local" -> {
            val h = host(input); val p = rp(h, input.req("remote_path")); val f = local(input.req("local_path"))
            val bytes = fs(h) { it.read(p) }
            f.parentFile?.mkdirs(); f.writeBytes(bytes); "Downloaded ${bytes.size} bytes to workspace/${f.relativeTo(workspace)}"
        }

        "panel_api" -> {
            val h = host(input)
            val params = (input["params"] as? JsonObject)?.mapValues { (_, v) -> (v as? JsonPrimitive)?.contentOrNull ?: v.toString() } ?: emptyMap()
            PanelApi.call(h, input.req("endpoint"), params, input.str("method") ?: "GET")
        }

        "ssh_exec" -> {
            val h = host(input)
            require(h.protocol == FileProtocol.SFTP) { "ssh_exec needs a host configured with SFTP (SSH)." }
            val timeout = (input.str("timeout_seconds")?.toLongOrNull() ?: 120L) * 1000
            SftpFs(h).use { it.exec(input.req("command"), timeout) }
        }

        "local_list" -> {
            val d = local(input.str("path"))
            if (!d.exists()) "Not found." else d.walkTopDown().maxDepth(4).filter { it != d }
                .joinToString("\n") { (if (it.isDirectory) "[dir]  " else "[file] ") + it.relativeTo(d).path + if (it.isFile) " (${it.length()} B)" else "" }
                .ifEmpty { "(empty)" }
        }
        "local_read" -> local(input.req("path")).readText().let { if (it.length > MAX_READ) it.take(MAX_READ) + "\n...[truncated]" else it }
        "local_write" -> {
            val f = local(input.req("path")); f.parentFile?.mkdirs(); f.writeText(input.req("content"))
            "Wrote ${f.length()} bytes to workspace/${f.relativeTo(workspace)}"
        }
        "local_delete" -> { val f = local(input.req("path")); require(f != workspace.canonicalFile) { "Refusing to delete the workspace root." }; f.deleteRecursively(); "Deleted." }

        "http_request" -> {
            val method = (input.str("method") ?: "GET").uppercase()
            val headers = (input["headers"] as? JsonObject)?.mapValues { (_, v) -> (v as? JsonPrimitive)?.contentOrNull ?: v.toString() } ?: emptyMap()
            val rb = Request.Builder().url(input.req("url"))
            headers.forEach { (k, v) -> rb.header(k, v) }
            val ct = headers.entries.firstOrNull { it.key.equals("Content-Type", true) }?.value?.toMediaTypeOrNull()
            if (method == "GET" || method == "HEAD") rb.method(method, null)
            else rb.method(method, (input.str("body") ?: "").toRequestBody(ct))
            Http.client.newCall(rb.build()).execute().use { r ->
                "HTTP ${r.code} ${r.message}\n" +
                    r.headers.joinToString("\n") { "${it.first}: ${it.second}" }.take(2000) +
                    "\n\n" + r.body?.string().orEmpty()
            }
        }

        else -> throw IllegalArgumentException("Unknown tool: $name")
    }

    fun systemPrompt(customInstructions: String): String = buildString {
        appendLine("You are HostAgent, an autonomous AI coding agent running inside an Android app.")
        appendLine("You build, edit, debug and deploy websites and code directly on the user's hosting accounts (cPanel, DirectAdmin and other hosts) using your tools.")
        appendLine()
        appendLine("Configured hosts:")
        val hs = hosts()
        if (hs.isEmpty()) appendLine("(none yet — tell the user to add one in the Hosts tab if a task needs a server)")
        hs.forEach { h ->
            appendLine("- \"${h.name}\": files via ${h.protocol}, root ${h.remoteRoot}, panel ${h.panelType}${if (h.notes.isNotBlank()) " — ${h.notes}" else ""}")
        }
        appendLine()
        appendLine("How to work:")
        appendLine("- Act, don't just describe: use the tools to actually carry out the user's request end to end.")
        appendLine("- In the 'host' parameter always use one of the exact host names listed above (in quotes), never a description.")
        appendLine("- Explore first (remote_list / remote_read) so your changes fit the existing code.")
        appendLine("- If the same tool call fails twice with the same error, stop retrying it and explain the problem to the user.")
        appendLine("- Before overwriting or deleting an important existing file, back it up (e.g. remote_rename/remote_write to name.bak-YYYYMMDD) unless the user says otherwise.")
        appendLine("- Use remote_edit for small changes, remote_write for new files or full rewrites. Write complete, working code — no placeholders.")
        appendLine("- Use panel_api for databases, domains, email, SSL etc. Never reveal passwords or API keys.")
        appendLine("- After deploying, verify with http_request when you know the site URL.")
        appendLine("- If a tool fails, read the error, adjust and retry; ask the user only when truly blocked.")
        appendLine("- Reply in the language the user writes in (often Persian/Farsi). End with a short summary of what changed.")
        appendLine("Today: ${SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())}")
        if (customInstructions.isNotBlank()) {
            appendLine()
            appendLine("User's custom instructions:")
            appendLine(customInstructions)
        }
    }
}
