package com.hostagent.app.agent

import com.hostagent.app.llm.ChatMsg
import com.hostagent.app.llm.LlmProvider
import com.hostagent.app.llm.ToolCall
import com.hostagent.app.llm.ToolResult
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

sealed class AgentEvent {
    data class Thinking(val on: Boolean) : AgentEvent()
    data class Text(val text: String) : AgentEvent()
    data class ToolStart(val call: ToolCall) : AgentEvent()
    data class ToolEnd(val call: ToolCall, val result: ToolResult) : AgentEvent()
    data class Notice(val text: String) : AgentEvent()
}

/**
 * The agent loop: ask the model -> run the tools it requests -> send results back -> repeat
 * until the model answers without tool calls (task done) or the step limit is reached.
 */
class AgentRunner(
    private val provider: LlmProvider,
    private val tools: AgentTools,
    private val requireApproval: Boolean,
    private val maxSteps: Int,
    private val approver: suspend (ToolCall) -> Boolean,
    private val onEvent: (AgentEvent) -> Unit
) {
    suspend fun run(history: MutableList<ChatMsg>, system: String) {
        var steps = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            if (steps++ >= maxSteps) {
                onEvent(AgentEvent.Notice("Step limit ($maxSteps) reached. Send \"continue\" to keep going."))
                return
            }

            onEvent(AgentEvent.Thinking(true))
            val resp = try {
                provider.complete(system, history, tools.definitions)
            } finally {
                onEvent(AgentEvent.Thinking(false))
            }

            history.add(ChatMsg.Assistant(resp.text, resp.toolCalls))
            if (resp.text.isNotBlank()) onEvent(AgentEvent.Text(resp.text))
            if (resp.toolCalls.isEmpty()) {
                if (resp.stopReason == "max_tokens" || resp.stopReason == "length") {
                    onEvent(AgentEvent.Notice("Response hit the max-tokens limit. Raise Max tokens for this provider or send \"continue\"."))
                }
                return
            }

            val results = mutableListOf<ToolResult>()
            try {
                for (call in resp.toolCalls) {
                    onEvent(AgentEvent.ToolStart(call))
                    val result = if (requireApproval && tools.needsApproval(call.name) && !approver(call)) {
                        ToolResult(call.id, "The user denied this action. Do not retry it; ask or choose another approach.", isError = true)
                    } else {
                        tools.execute(call)
                    }
                    results.add(result)
                    onEvent(AgentEvent.ToolEnd(call, result))
                }
            } finally {
                // Every tool call must have a result, even when the user pressed Stop mid-way.
                val done = results.map { it.toolCallId }.toSet()
                resp.toolCalls.filter { it.id !in done }.forEach { results.add(ToolResult(it.id, "Cancelled by user.", isError = true)) }
                history.add(ChatMsg.Tools(results))
            }
        }
    }
}
