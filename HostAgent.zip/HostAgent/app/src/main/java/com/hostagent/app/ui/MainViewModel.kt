package com.hostagent.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hostagent.app.agent.AgentEvent
import com.hostagent.app.agent.AgentRunner
import com.hostagent.app.agent.AgentTools
import com.hostagent.app.data.AppSettings
import com.hostagent.app.data.FileProtocol
import com.hostagent.app.data.HostConfig
import com.hostagent.app.data.PanelType
import com.hostagent.app.data.ProviderConfig
import com.hostagent.app.data.ProviderType
import com.hostagent.app.data.Store
import com.hostagent.app.llm.AnthropicProvider
import com.hostagent.app.llm.ChatMsg
import com.hostagent.app.llm.LlmProvider
import com.hostagent.app.llm.OpenAICompatProvider
import com.hostagent.app.llm.ToolCall
import com.hostagent.app.llm.ToolResult
import com.hostagent.app.remote.PanelApi
import com.hostagent.app.remote.RemoteFsFactory
import com.hostagent.app.remote.RemotePath
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class UiItem {
    abstract val key: String

    data class User(val text: String, override val key: String = UUID.randomUUID().toString()) : UiItem()
    data class Assistant(val text: String, override val key: String = UUID.randomUUID().toString()) : UiItem()
    data class Tool(val call: ToolCall, val result: ToolResult? = null, override val key: String = UUID.randomUUID().toString()) : UiItem()
    data class Info(val text: String, val isError: Boolean = false, override val key: String = UUID.randomUUID().toString()) : UiItem()
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)

    var providers by mutableStateOf(store.loadProviders()); private set
    var hosts by mutableStateOf(store.loadHosts()); private set
    var settings by mutableStateOf(store.loadSettings()); private set
    var selectedProviderId by mutableStateOf(store.loadSelectedProvider()); private set

    val selectedProvider: ProviderConfig?
        get() = providers.firstOrNull { it.id == selectedProviderId } ?: providers.firstOrNull()

    val items = mutableStateListOf<UiItem>()
    var running by mutableStateOf(false); private set
    var thinking by mutableStateOf(false); private set
    var pendingApproval by mutableStateOf<ToolCall?>(null); private set

    private var approvalDeferred: CompletableDeferred<Boolean>? = null
    private var autoApproveSession = false
    private var history = mutableListOf<ChatMsg>()
    private var job: Job? = null

    val tools = AgentTools(app) { hosts }

    // ------------------------------------------------------------- providers / hosts / settings

    fun upsertProvider(p: ProviderConfig) {
        providers = upsert(providers, p) { it.id }
        store.saveProviders(providers)
        if (selectedProviderId == null) selectProvider(p.id)
    }

    fun deleteProvider(p: ProviderConfig) {
        providers = providers.filterNot { it.id == p.id }
        store.saveProviders(providers)
        if (selectedProviderId == p.id) selectProvider(providers.firstOrNull()?.id)
    }

    fun selectProvider(id: String?) {
        selectedProviderId = id
        store.saveSelectedProvider(id)
    }

    fun upsertHost(h: HostConfig) {
        hosts = upsert(hosts, h) { it.id }
        store.saveHosts(hosts)
    }

    fun deleteHost(h: HostConfig) {
        hosts = hosts.filterNot { it.id == h.id }
        store.saveHosts(hosts)
    }

    fun updateSettings(s: AppSettings) {
        settings = s
        store.saveSettings(s)
    }

    private fun <T> upsert(list: List<T>, item: T, id: (T) -> String): List<T> {
        val i = list.indexOfFirst { id(it) == id(item) }
        return if (i >= 0) list.toMutableList().also { it[i] = item } else list + item
    }

    private fun createProvider(cfg: ProviderConfig): LlmProvider = when (cfg.type) {
        ProviderType.ANTHROPIC -> AnthropicProvider(cfg)
        ProviderType.OPENAI_COMPATIBLE -> OpenAICompatProvider(cfg)
    }

    fun testProvider(cfg: ProviderConfig, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val r = runCatching {
                createProvider(cfg).complete("You are a connection test.", listOf(ChatMsg.User("Reply with just: OK")), emptyList()).text
            }
            onResult(r.fold({ "✅ پاسخ مدل: ${it.take(200)}" }, { "❌ ${it.message}" }))
        }
    }

    fun testHost(h: HostConfig, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                buildString {
                    if (h.protocol != FileProtocol.NONE) {
                        val res = runCatching {
                            val root = RemotePath.resolve(h.remoteRoot, "")
                            RemoteFsFactory.open(h).use { it.list(root) }.size
                        }
                        append(res.fold({ "✅ ${h.protocol}: اتصال موفق ($it مورد در ریشه)" }, { "❌ ${h.protocol}: ${it.message}" }))
                    }
                    if (h.panelType != PanelType.NONE) {
                        if (isNotEmpty()) append("\n")
                        val res = runCatching { PanelApi.ping(h) }
                        append(res.fold({ (if (it.startsWith("HTTP 200")) "✅ " else "⚠️ ") + "${h.panelType}: ${it.take(300)}" }, { "❌ ${h.panelType}: ${it.message}" }))
                    }
                    if (isEmpty()) append("هیچ روش اتصالی انتخاب نشده است.")
                }
            }
            onResult(r)
        }
    }

    // ------------------------------------------------------------- chat / agent

    fun send(text: String) {
        if (running || text.isBlank()) return
        val cfg = selectedProvider
        if (cfg == null) {
            items.add(UiItem.Info("ابتدا در تب «پرووایدرها» یک پرووایدر اضافه کنید.", isError = true))
            return
        }
        items.add(UiItem.User(text))
        val h = history
        h.add(ChatMsg.User(text))
        running = true
        job = viewModelScope.launch {
            try {
                AgentRunner(
                    provider = createProvider(cfg),
                    tools = tools,
                    requireApproval = settings.requireApproval,
                    maxSteps = settings.maxSteps,
                    approver = ::requestApproval,
                    onEvent = ::onEvent
                ).run(h, tools.systemPrompt(settings.customInstructions))
            } catch (e: CancellationException) {
                items.add(UiItem.Info("متوقف شد."))
            } catch (e: Exception) {
                items.add(UiItem.Info("خطا: ${e.message}", isError = true))
            } finally {
                running = false
                thinking = false
                pendingApproval = null
            }
        }
    }

    fun stop() {
        approvalDeferred?.complete(false)
        job?.cancel()
    }

    fun newChat() {
        stop()
        history = mutableListOf()
        items.clear()
        autoApproveSession = false
    }

    private suspend fun requestApproval(call: ToolCall): Boolean {
        if (autoApproveSession) return true
        val d = CompletableDeferred<Boolean>()
        approvalDeferred = d
        pendingApproval = call
        return try {
            d.await()
        } finally {
            pendingApproval = null
            approvalDeferred = null
        }
    }

    fun answerApproval(allow: Boolean, always: Boolean = false) {
        if (always) autoApproveSession = true
        approvalDeferred?.complete(allow)
    }

    private fun onEvent(e: AgentEvent) {
        when (e) {
            is AgentEvent.Thinking -> thinking = e.on
            is AgentEvent.Text -> items.add(UiItem.Assistant(e.text))
            is AgentEvent.ToolStart -> items.add(UiItem.Tool(e.call))
            is AgentEvent.ToolEnd -> {
                val i = items.indexOfLast { it is UiItem.Tool && it.call.id == e.call.id }
                if (i >= 0) items[i] = (items[i] as UiItem.Tool).copy(result = e.result)
            }
            is AgentEvent.Notice -> items.add(UiItem.Info(e.text))
        }
    }
}
