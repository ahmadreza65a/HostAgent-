package com.hostagent.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/** Stores providers, hosts and settings. API keys and passwords are encrypted with Android Keystore. */
class Store(context: Context) {

    private val prefs: SharedPreferences = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "hostagent_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        context.getSharedPreferences("hostagent_fallback", Context.MODE_PRIVATE)
    }

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun loadProviders(): List<ProviderConfig> = read("providers") ?: emptyList()
    fun saveProviders(list: List<ProviderConfig>) = write("providers", json.encodeToString(list))

    fun loadHosts(): List<HostConfig> = read("hosts") ?: emptyList()
    fun saveHosts(list: List<HostConfig>) = write("hosts", json.encodeToString(list))

    fun loadSettings(): AppSettings = read("settings") ?: AppSettings()
    fun saveSettings(s: AppSettings) = write("settings", json.encodeToString(s))

    fun loadSelectedProvider(): String? = prefs.getString("selected_provider", null)
    fun saveSelectedProvider(id: String?) = prefs.edit().putString("selected_provider", id).apply()

    private inline fun <reified T> read(key: String): T? =
        prefs.getString(key, null)?.let { runCatching { json.decodeFromString<T>(it) }.getOrNull() }

    private fun write(key: String, value: String) = prefs.edit().putString(key, value).apply()
}
