package com.hostagent.app.remote

import com.hostagent.app.data.HostConfig
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPReply
import org.apache.commons.net.ftp.FTPSClient
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Locale

/** FTP and explicit FTPS (FTP over TLS) — works with cPanel, DirectAdmin, Plesk and most shared hosts. */
class FtpFs(private val h: HostConfig, secure: Boolean) : RemoteFs {

    private val ftp: FTPClient = if (secure) FTPSClient("TLS", false) else FTPClient()
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    init {
        ftp.connectTimeout = 20_000
        ftp.defaultTimeout = 30_000
        ftp.controlEncoding = "UTF-8"
        ftp.connect(h.host.trim(), if (h.port > 0) h.port else 21)
        if (!FTPReply.isPositiveCompletion(ftp.replyCode)) {
            val r = ftp.replyString
            ftp.disconnect()
            throw IOException("FTP server refused connection: $r")
        }
        ftp.soTimeout = 60_000
        if (!ftp.login(h.username, h.password)) {
            val r = ftp.replyString
            runCatching { ftp.disconnect() }
            throw IOException("FTP login failed: ${r.trim()}")
        }
        if (ftp is FTPSClient) {
            ftp.execPBSZ(0)
            ftp.execPROT("P")
        }
        ftp.enterLocalPassiveMode()
        ftp.setFileType(FTP.BINARY_FILE_TYPE)
    }

    override fun list(path: String): List<RemoteEntry> =
        ftp.listFiles(path).filter { it.name != "." && it.name != ".." }.map {
            RemoteEntry(it.name, it.isDirectory, it.size, it.timestamp?.time?.let { d -> fmt.format(d) } ?: "")
        }

    override fun read(path: String): ByteArray {
        val out = ByteArrayOutputStream()
        if (!ftp.retrieveFile(path, out)) throw IOException("Cannot read $path: ${ftp.replyString.trim()}")
        return out.toByteArray()
    }

    override fun write(path: String, data: ByteArray) {
        mkdirs(RemotePath.parent(path))
        if (!ftp.storeFile(path, ByteArrayInputStream(data))) throw IOException("Cannot write $path: ${ftp.replyString.trim()}")
    }

    override fun mkdirs(path: String) {
        var cur = ""
        for (seg in path.split('/').filter { it.isNotEmpty() }) {
            cur += "/$seg"
            if (!ftp.changeWorkingDirectory(cur) && !ftp.makeDirectory(cur)) {
                throw IOException("mkdir $cur failed: ${ftp.replyString.trim()}")
            }
        }
        ftp.changeWorkingDirectory("/")
    }

    override fun delete(path: String) {
        if (ftp.deleteFile(path)) return
        // Probably a directory: delete recursively.
        ftp.listFiles(path).filter { it.name != "." && it.name != ".." }.forEach { delete("$path/${it.name}") }
        if (!ftp.removeDirectory(path)) throw IOException("Cannot delete $path: ${ftp.replyString.trim()}")
    }

    override fun rename(from: String, to: String) {
        mkdirs(RemotePath.parent(to))
        if (!ftp.rename(from, to)) throw IOException("Rename failed: ${ftp.replyString.trim()}")
    }

    override fun close() {
        runCatching { ftp.logout() }
        runCatching { ftp.disconnect() }
    }
}
