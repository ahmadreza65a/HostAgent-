package com.hostagent.app.remote

import com.hostagent.app.data.FileProtocol
import com.hostagent.app.data.HostConfig
import java.io.Closeable

data class RemoteEntry(val name: String, val isDir: Boolean, val size: Long, val modified: String)

/** Common file operations over FTP / FTPS / SFTP. Paths are absolute on the server. */
interface RemoteFs : Closeable {
    fun list(path: String): List<RemoteEntry>
    fun read(path: String): ByteArray
    fun write(path: String, data: ByteArray)
    fun mkdirs(path: String)
    fun delete(path: String)
    fun rename(from: String, to: String)
}

object RemoteFsFactory {
    fun open(h: HostConfig): RemoteFs = when (h.protocol) {
        FileProtocol.FTP -> FtpFs(h, secure = false)
        FileProtocol.FTPS -> FtpFs(h, secure = true)
        FileProtocol.SFTP -> SftpFs(h)
        FileProtocol.NONE -> throw IllegalStateException("Host '${h.name}' has no file protocol configured (use panel_api instead).")
    }
}

object RemotePath {
    /** Relative paths are resolved against the host root; paths starting with "/" are used as-is. */
    fun resolve(root: String, path: String): String {
        val p = path.trim()
        val joined = if (p.startsWith("/")) p else "${root.ifBlank { "/" }.trimEnd('/')}/$p"
        val parts = ArrayDeque<String>()
        joined.split('/').forEach { seg ->
            when (seg) {
                "", "." -> {}
                ".." -> parts.removeLastOrNull()
                else -> parts.addLast(seg)
            }
        }
        return "/" + parts.joinToString("/")
    }

    fun parent(path: String): String = path.substringBeforeLast('/', "").ifEmpty { "/" }
}
